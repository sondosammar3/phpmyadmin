  
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../CSS/bootstrap.min.css" >
    <link rel="stylesheet" href="../CSS/index.css" >

</head>
<body>
     <!-- navbar -->
     <form action="<?php echo $_SERVER["PHP_SELF"];?>" >
     <nav class="navbar navbar-expand-lg bg-body-tertiary fixed-top">
        <div class="container">
            <span class="text-white navbar-brand  ">User Page</span>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>   
          
        </div>
    </nav>
    
    <section style="background-image: url(../images/userpage.jpg); height: 100vh;background-repeat: no-repeat; background-size: cover;height: 100vh;display: flex; align-items: center;">
        <div class="container" style="font-family: 'Raleway', sans-serif;">
            <div class="row justify-content-between">
                <h2 class="text-white col-md-5">Welcome </h2>
               
            </div>
        </div>
    </section>


</form>





    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>