<?php

$conn= new mysqli("localhost","root","","database");

?>