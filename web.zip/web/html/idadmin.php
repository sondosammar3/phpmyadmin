<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <?php
    include 'connection.php';
    session_start();

    if(isset($_POST['submit'])){
        $id = $_POST['id'];
        $sql= "SELECT * from admins where id='$id'";
        $select=mysqli_query($conn,$sql);
        if (mysqli_num_rows($select) > 0) {
            $_SESSION['id']=$id;
            header("location:updateadmin.php");
        }else echo "<script>alert('no valid id')</script>";;
        
    }
    
    ?>
</head>
<body>
    <form action="" method="post">
         enter id: <input type="text" name="id">
        <input type="submit" value="submit" name="submit">
    </form>
</body>
</html>