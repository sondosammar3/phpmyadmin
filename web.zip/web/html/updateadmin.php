
            <?php
          include 'connection.php';

          session_start();
          $up=$_SESSION['id'];
                $sql= "SELECT * from `admins` where `id`='$up'";
$select=mysqli_query($conn,$sql); 
    $row=mysqli_fetch_array($select);  
      $name=$row["name"];
      $email=$row["email"];
      $password=$row["password"];echo "password=",$password;
       $phone=$row["phonenumber"]; 
       $p=$row["pic"];
            if (isset($up)){ 
            if(isset($_POST["done"])){
                $name1=$_POST["full_name"];
                $email1=$_POST["email"];
                $password1=$_POST["password"];
                $phone1=$_POST["phone"];
                $photo_name=$_FILES ['photo']['name']; 
           $photo_path=$_FILES ['photo']['tmp_name'];

               if (empty($_FILES ['photo']['name'])){
                $update= "UPDATE `admins` SET `name` = ' $name1', `email` = '$email1', `password` = '$password1', `phonenumber` = '$phone1' ,`pic`='$p'
               where `id` = '$up'";
         $query2=mysqli_query($conn,$update);
           $move=move_uploaded_file($photo_path,"../images/$p");

                if($query2 ){
                    echo '<script>alert("the admin is updated ");window.location.assign("adminpage.php");</script>';
                }
                else  echo "no";
                
                
            }
        else {

  
            $update= "UPDATE `user` SET `name` = ' $name1', `email` = '$email1', `password` = '$password1', `phonenumber` = '$phone1' ,`pic`='$photo_name'
            where `id` = '$up'";
                 $query2=mysqli_query($conn,$update);
               $move=move_uploaded_file($photo_path,"../images/$photo_name");
               
             if($query2 ){
                 echo '<script>alert("the  admin is updated ");window.location.assign("adminpage.php");</script>';
             }
             else  echo "no";}


        
        }
            }

           
                    ?>

            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>update</title>
    <link rel="stylesheet" href="../CSS/to_signUp.css">
</head>
<body>
    
    <div class="signup">
        <h2 style="display:inline-block ;">Sign Up</h2>
       
        <br>
        <form action="<?php echo $_SERVER["PHP_SELF"];?>" method="post" enctype="multipart/form-data">
            <div>
                <label for="full_name">Name</label>
                <br>
                <input type="text" id="full_name" name="full_name" value= "<?php echo $name ;?>">
            </div>
            <br>
            <div>
                <label for="email">Email</label>
                <br>
                <input type="email" id="email" name="email"value=" <?php   echo $email ;?>  ">
            </div>
            <br> 
            <div>
                <label for="pass">Password</label>
                <br>
                <input type="password" id="pass" name="password"value= "<?php   echo $password ;?>">
            </div>
            <br>
            <div>
                <label for="phone">Phone Number</label>
                <input type="number" id="phone" name="phone"value=" <?php   echo $phone ;?> ">
            </div>
            <br>
            <label for="photo">Photo</label>
            <input type="file" id="photo" name="photo" accept=".png,.jpg,.jpeg" >
            <br> <br> <br>
            <input type="submit" value="Done" id="submit" name="done">
            <br> <br>

           
        </form>

    </div>
</body>
</html>