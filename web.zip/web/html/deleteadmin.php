<?php
include 'connection.php';

if(isset($_GET['deletedid'])){
    
    $id=$_GET['deletedid'];
$sql="DELETE FROM `admins` where `id`='$id'";
$query=mysqli_query($conn,$sql);
if ($query){
    echo '<script>alert("the admin is deleted");window.location.assign("adminpage.php");</script>';

}

}
?>
